import re
from aig_subgraph_miner import AIG, mine_frequent_subgraphs, Pattern
pin_re=re.compile(r"\.(\w+)\s*\(\s*([^()]+?)\s*\)"); inst_re=re.compile(r"(?ms)^\s*([A-Za-z_]\w*)\s+([A-Za-z_\\][\w\\\[\]\$]*)\s*\((.*?)\)\s*;")
def _split(s):
 from re import sub; return [sub(r"\[[^\]]+\]\s*","",x).strip() for x in s.replace("\n"," ").split(",") if x.strip()]
def extract_modules(t):
 import re; mod_re=re.compile(r"(?ms)module\s+([A-Za-z_]\w*)\s*\(.*?\)\s*;(.*?)endmodule");
 ms=mod_re.findall(t); return ms or [(re.search(r"module\s+([A-Za-z_]\w*)",t).group(1) if re.search(r"module\s+([A-Za-z_]\w*)",t) else "top", t)]
def parse_module_to_ir(name, body):
 import re
 pi,po=[],[]
 [pi.extend(_split(m.group(1))) for m in re.finditer(r"^\s*input\b([^;]*);", body, flags=re.M)]
 [po.extend(_split(m.group(1))) for m in re.finditer(r"^\s*output\b([^;]*);", body, flags=re.M)]
 ands,bufs,piq,pod,sk=[],[],[],[],[]
 for m in inst_re.finditer(body):
  cell,inst,pinblk=m.group(1),m.group(2),m.group(3); pins={pm.group(1):pm.group(2).strip() for pm in pin_re.finditer(pinblk)}; cl=cell.lower()
  if cl.startswith("logic0") or cl.startswith("tiel") or cl.startswith("logic1") or cl.startswith("tieh"):
   sk.append({"type":cell,"inst":inst,"reason":"const"}); continue
  if cl.startswith("inv"):
   i=pins.get("I") or pins.get("A") or pins.get("IN"); z=pins.get("ZN") or pins.get("Z") or pins.get("Y");
   (bufs.append({"out":z,"in":i,"inv":True}) if (i and z) else sk.append({"type":cell,"inst":inst,"reason":"pins"})); continue
  if cl.startswith("buf"):
   i=pins.get("I") or pins.get("A") or pins.get("IN"); z=pins.get("Z") or pins.get("Y") or pins.get("ZN");
   if i and z:
    inv=False; inv=True if ("ZN" in pins and "Z" not in pins and "Y" not in pins) else None
    bufs.append({"out":z,"in":i,"inv":bool(inv)})
   else: sk.append({"type":cell,"inst":inst,"reason":"pins"}); continue
  if cl.startswith("nand2") or cl=="nand2":
   a1=pins.get("A1") or pins.get("A"); a2=pins.get("A2") or pins.get("B"); z=pins.get("ZN") or pins.get("Z") or pins.get("Y");
   (ands.append({"out":z,"in0":a1,"in0_inv":False,"in1":a2,"in1_inv":False,"out_inv":True}) if (a1 and a2 and z) else sk.append({"type":cell,"inst":inst,"reason":"pins"})); continue
  if cl.startswith("nor2") or cl=="nor2":
   a1=pins.get("A1") or pins.get("A"); a2=pins.get("A2") or pins.get("B"); z=pins.get("ZN") or pins.get("Z") or pins.get("Y");
   (ands.append({"out":z,"in0":a1,"in0_inv":True,"in1":a2,"in1_inv":True,"out_inv":False}) if (a1 and a2 and z) else sk.append({"type":cell,"inst":inst,"reason":"pins"})); continue
  if cl.startswith("dff"):
   q=pins.get("Q") or pins.get("QN"); d=pins.get("D");
   (piq.append(q) if q else None); (pod.append(d) if d else None); continue
  sk.append({"type":cell,"inst":inst,"reason":"unsupported"})
 return {"module":name,"primary_inputs":pi,"primary_outputs":po,"ands":ands,"bufs":bufs,"pi_from_seq":sorted(set(piq)),"po_to_seq":sorted(set(pod)),"skipped_cells":sk}
def parse_verilog_to_ir_per_module(vtext:str): return {n:parse_module_to_ir(n,b) for n,b in extract_modules(vtext)}
def build_aig_from_ir(ir:dict):
 g=AIG(); net2ref={}
 def ref_of(net):
  if net in net2ref: return net2ref[net]
  nid=g.add_pi(net); net2ref[net]=(nid,False); return net2ref[net]
 for n in ir.get("primary_inputs",[]):
  if n not in net2ref: net2ref[n]=(g.add_pi(n),False)
 for n in ir.get("pi_from_seq",[]):
  if n not in net2ref: net2ref[n]=(g.add_pi(n),False)
 for b in ir.get("bufs",[]):
  s_id,s_inv=ref_of(b["in"]); net2ref[b["out"]]=(s_id, s_inv ^ bool(b.get("inv",False)))
 for a in ir.get("ands",[]):
  in0_id,in0_inv=ref_of(a["in0"]); in0_inv ^= bool(a.get("in0_inv",False))
  in1_id,in1_inv=ref_of(a["in1"]); in1_inv ^= bool(a.get("in1_inv",False))
  nid=g.add_and(in0_id,in1_id,inv_a=in0_inv,inv_b=in1_inv,name=a.get("out"))
  net2ref[a["out"]]=(nid, bool(a.get("out_inv",False)))
 for name in (ir.get("primary_outputs",[])+ir.get("po_to_seq",[])):
  if name in net2ref:
   nid,inv=net2ref[name]; g.add_po(nid, inv=inv, name=name)
  else:
   nid=g.add_pi(name+"__dangling"); g.add_po(nid, inv=False, name=name)
 return g
def mine_across_modules(ir_per_module, dmax=4, kmax=4, mmax=1, min_support=5, **kwargs):
 global_patterns={}; per_module_patterns={}
 for mod, ir in ir_per_module.items():
  g=build_aig_from_ir(ir)
  pats=mine_frequent_subgraphs(g, dmax=dmax, kmax=kmax, mmax=mmax, min_support=1, cap_per_node=400, use_random_bucket=True, **kwargs)
  per_module_patterns[mod]=pats
  for key,p in pats.items():
   if key not in global_patterns:
    global_patterns[key]=Pattern(k=p.k, m=p.m, canonical_outputs=p.canonical_outputs, count=p.count, example=p.example)
   else:
    global_patterns[key].count += p.count
 global_patterns={k:v for k,v in global_patterns.items() if v.count >= min_support}
 return global_patterns, per_module_patterns
