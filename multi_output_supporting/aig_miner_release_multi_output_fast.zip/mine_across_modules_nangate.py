import argparse, json
from pathlib import Path
import verilog_multi_to_aig_nangate as mm
from aig_subgraph_miner import summarize_patterns
def main():
 ap=argparse.ArgumentParser(); ap.add_argument("verilog"); ap.add_argument("--dmax",type=int,default=4);
 ap.add_argument("--kmax",type=int,default=4); ap.add_argument("--mmax",type=int,default=1);
 ap.add_argument("--min_support",type=int,default=5); ap.add_argument("--out_prefix",default="multi");
 ap.add_argument("--matrix_csv",action="store_true"); ap.add_argument("--max_root_sets",type=int,default=1000);
 ap.add_argument("--root_enum_strategy", default="mixed", choices=["all","po_group","fanout_neighbors","mixed"]);
 ap.add_argument("--neighbor_radius", type=int, default=2);
 ap.add_argument("--limit_per_seed", type=int, default=200);
 ap.add_argument("--prefer_po_only", action="store_true");
 args=ap.parse_args(); v=Path(args.verilog).read_text(encoding="utf-8", errors="ignore");
 ir=mm.parse_verilog_to_ir_per_module(v);
 Path(f"{args.out_prefix}_ir_per_module.json").write_text(json.dumps(ir,indent=2), encoding="utf-8")
 gp,pm = mm.mine_across_modules(ir, dmax=args.dmax, kmax=args.kmax, mmax=args.mmax, min_support=args.min_support,
   max_root_sets=args.max_root_sets, root_enum_strategy=args.root_enum_strategy, neighbor_radius=args.neighbor_radius,
   limit_per_seed=args.limit_per_seed, prefer_po_only=args.prefer_po_only)
 print(summarize_patterns(gp, top=50))
if __name__=="__main__": main()
